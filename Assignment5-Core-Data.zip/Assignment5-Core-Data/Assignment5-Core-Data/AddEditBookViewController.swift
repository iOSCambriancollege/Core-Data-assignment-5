//
//  AddEditBookViewController.swift
//  Assignment5-Core-Data
//
//

import UIKit
import CoreData

protocol AddEditBookViewControllerDelegate {
    func didSaveBook(title: String, publicationYear: Int, synopsis: String, author: Author)
}

class AddEditBookViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    var authors: [Author] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    var delegate: AddEditBookViewControllerDelegate?
    var selectedAuthor: Author?
    @IBOutlet weak var author: UIPickerView!
    @IBOutlet weak var synopsis: UITextView!
    @IBOutlet weak var publicationYear: UITextField!
    @IBOutlet weak var bookTitle: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        author.delegate = self

        let fetchRequest: NSFetchRequest<Author> = Author.fetchRequest()
        do {
            author.delegate = self
            author.dataSource = self
            authors = try context.fetch(fetchRequest)
        } catch {
            print("Failed to fetch authors: \(error)")
        }

        // Do any additional setup after loading the view.
        // print(authors)
    }

    func pickerView(_ author: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return authors.count
    }

    func pickerView(_ author: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let author = authors[row]
        return "\(author.firstname!) \(author.lastname!)"
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedAuthor = authors[row]
    }

    @IBAction func submitBook(_ sender: Any) {
        let title = bookTitle.text ?? ""
        let pubYear = Int(publicationYear.text ?? "") ?? 0
        let synopsis = synopsis.text ?? ""
        let author = selectedAuthor

        delegate?.didSaveBook(title: title, publicationYear: pubYear, synopsis: synopsis, author: author!)

        navigationController?.popViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
