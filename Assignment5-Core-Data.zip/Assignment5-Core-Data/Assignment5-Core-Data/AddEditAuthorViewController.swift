//
//  AddEditAuthorViewController.swift
//  Assignment5-Core-Data
//
//

import UIKit

protocol AddEditAuthorViewControllerDelegate {
    func didSaveAuthor(firstName: String, lastName: String)
}

class AddEditAuthorViewController: UIViewController {
    var delegate: AddEditAuthorViewControllerDelegate?
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var firstName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func submitAuthor(_ sender: Any) {
        let fname = firstName.text ?? ""
        let lname = lastName.text ?? ""

        delegate?.didSaveAuthor(firstName: fname, lastName: lname)
        navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
